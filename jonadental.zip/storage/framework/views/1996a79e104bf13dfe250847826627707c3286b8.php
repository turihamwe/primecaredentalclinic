<?php if(count($errors) > 0): ?>
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="alert alert-danger alert-dismissable text-center col-md-12 col-md-offset-4">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<?php echo e($error); ?>

		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
	<div class="alert alert-success alert-dismissable text-center col-md-12 col-md-offset-4">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		<?php echo e(session('success')); ?>

	</div>
<?php endif; ?>

<?php if(session('error')): ?>
	<div class="alert alert-danger alert-dismissable text-center col-md-12 col-md-offset-4">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		<?php echo e(session('error')); ?>

	</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\1COMPLETE\jonadental\resources\views/layouts/messages.blade.php ENDPATH**/ ?>