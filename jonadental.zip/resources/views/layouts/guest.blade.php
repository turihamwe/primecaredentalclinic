@include('layouts.guest.header')
@include('layouts.guest.navigation')
{{-- @include('layouts.guest.title') --}}
@yield('content')
@include('layouts.guest.footer')