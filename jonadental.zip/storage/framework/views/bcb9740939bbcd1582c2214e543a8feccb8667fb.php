<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title> <?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
	<link rel="shortcut icon" href="<?php echo e(asset('images/fav.jpg')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/fontawsom-all.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('plugins/testimonial/css/owl.carousel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('plugins/testimonial/css/owl.theme.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>" />
</head>

<body><?php /**PATH C:\wamp64\www\1COMPLETE\jonadental\resources\views/layouts/guest/header.blade.php ENDPATH**/ ?>