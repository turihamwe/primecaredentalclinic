<!--  ************************* Page Title Starts Here ************************** -->
<div class="page-nav no-margin row">
	<div class="container">
		<div class="row">
			<h2>Our Blog</h2>
			<ul>
				<li> <a href="#"><i class="fas fa-home"></i> Home</a></li>
				<li><i class="fas fa-angle-double-right"></i> Blog </li>
			</ul>
		</div>
	</div>
</div>
<!-- ######## Page  Title End ####### --><?php /**PATH C:\wamp64\www\1COMPLETE\jonadental\resources\views/layouts/guest/title.blade.php ENDPATH**/ ?>