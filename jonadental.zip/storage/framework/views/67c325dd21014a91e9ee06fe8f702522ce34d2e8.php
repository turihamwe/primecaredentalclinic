		<footer class="footer">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-sm-12">
						<h2>About Us</h2>
						<p><?php echo e(config('app.name')); ?> is a leading provider of dental services, consulting, and business process services. Our dedicated employees offer strategic insights, technological expertise and industry experience.</p>
						<p>We focus on technologies that promise to reduce costs, streamline processes and speed time-to-market, Backed by our strong quality processes and rich experience managing global... </p>
						<p>&nbsp;</p><br>
					</div>
					<div class="col-md-4 col-sm-12">
						<h2>&nbsp;</h2>
						<ul class="list-unstyled link-list">
							<li><a ui-sref="about" href="<?php echo e(route('/')); ?>">Home</a><i class="fa fa-angle-right"></i></li>
							<li><a ui-sref="portfolio" href="<?php echo e(route('about')); ?>">About us</a><i class="fa fa-angle-right"></i></li>
							<li><a ui-sref="products" href="<?php echo e(route('services')); ?>">Services</a><i class="fa fa-angle-right"></i></li>
							<li><a ui-sref="gallery" href="<?php echo e(route('contact')); ?>">Contact us</a><i class="fa fa-angle-right"></i></li>
						</ul>
					</div>
					<div class="col-md-4 col-sm-12 map-img">
						<h2>Contact Us</h2>
						<address class="md-margin-bottom-40">
							<?php echo e(env('ADDRESS_1')); ?><br>
							<?php echo e(env('ADDRESS_2')); ?> <br>
							Phone 1: <?php echo e(env('PHONE_1')); ?> <br>
							Phone 2: <?php echo e(env('PHONE_2')); ?> <br>
							Email: <a href="mailto:<?php echo e(env('EMAIL_INFO')); ?>" class="text-info"><?php echo e(env('EMAIL_INFO')); ?></a><br>
							Web: <a href="<?php echo e(config('app.url')); ?>" class="text-info"><?php echo e(config('app.url')); ?></a>
						</address>
					</div>
				</div>
			</div>
		</footer>
		<div class="copy">
			<div class="container">
				<a><?php echo e(date("Y")); ?> &copy; <?php echo e(config('app.name')); ?>. All Rights Reserved.</a>
				<span>
					<a href="<?php echo e(route('/')); ?>"><i class="fab fa-github"></i></a>
					<a href="<?php echo e(route('/')); ?>"><i class="fab fa-google-plus-g"></i></a>
					<a href="<?php echo e(route('/')); ?>"><i class="fab fa-pinterest-p"></i></a>
					<a href="<?php echo e(route('/')); ?>"><i class="fab fa-twitter"></i></a>
					<a href="<?php echo e(route('/')); ?>"><i class="fab fa-facebook-f"></i></a>
				</span>
			</div>
		</div>
	</body>
	<script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugins/scroll-fixed/jquery-scrolltofixed-min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugins/testimonial/js/owl.carousel.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/script.js')); ?>"></script>
</html><?php /**PATH C:\wamp64\www\1COMPLETE\jonadental\resources\views/layouts/guest/footer.blade.php ENDPATH**/ ?>