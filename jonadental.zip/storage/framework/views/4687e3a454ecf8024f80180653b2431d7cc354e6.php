<!-- ################# Header Starts Here#######################--->
<header id="menu-jk">
	<div class="container">
		<div class="row top">
			<div class="col-md-3 d-none d-lg-block">
				<div class="call d-flex">
					<i class="fas fa-phone"></i>
					<div class="call-no"><?php echo e(env('PHONE_1')); ?><br><?php echo e(env('PHONE_2')); ?></div>
				</div>
			</div>
			<div class="col-lg-6 col-md-7 logo">
				<a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>" alt=""></a>
				<a data-toggle="collapse" data-target="#menu" href="#menu"><i class="fas d-block d-md-none small-menu fa-bars"></i></a>
			</div>
			<div class="col-lg-3 col-md-5 d-none d-md-block call-r">
				<div class="call d-flex">
					<i class="fas fa-map-marker-alt"></i>
					<div class="call-no"><?php echo e(env('ADDRESS_1')); ?><br><?php echo e(env('ADDRESS_2')); ?></div>
				</div>
			</div>
		</div>
	</div>
	<nav id="menu" class="d-none d-md-block">
		<div class="container">
			<div class="row nav-ro">
				<ul>
					<li><a href="<?php echo e(route('/')); ?>">Home</a></li>
					<li><a href="<?php echo e(route('about')); ?>">About us</a></li>
					<li><a href="<?php echo e(route('services')); ?>">Services</a></li>
					
					
					<li><a href="<?php echo e(route('contact')); ?>">Contact us</a></li>
					<li><a href="<?php echo e(route('appointment')); ?>" class="btn btn-sm btn-success">Book an appointment</a></li>
					
				</ul>
			</div>
		</div>
	</nav>
</header><?php /**PATH C:\wamp64\www\1COMPLETE\jonadental\resources\views/layouts/guest/navigation.blade.php ENDPATH**/ ?>